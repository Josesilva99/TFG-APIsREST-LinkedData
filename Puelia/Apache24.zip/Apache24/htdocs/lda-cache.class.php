<?php

require_once 'lda.inc.php';

class LinkedDataApiCachedResponse
{
	var $eTag;
	var $generatedTime;
	var $lastModified;
	var $mimetype;
	var $body;
	var $cacheable;

	function serve()
	{
		header("Content-type: {$this->mimetype}");
		header("Last-Modified: {$this->lastModified}");
		header("ETag: {$this->eTag}");
		header("x-served-from-cache: true");
		echo $this->body;
	}
}

class LinkedDataApiCache
{
	public static function hasCachedResponse(LinkedDataApiRequest $request)
	{
		logDebug('Looking for a cached response');
		$acceptableTypes = $request->getAcceptTypes();
		$uri = $request->uri;
		foreach ($acceptableTypes as $mimetype)
		{
			$key = LinkedDataApiCache::cacheKey($uri, $mimetype);
			//todo make memcache host and port configurable
			$mc = memcache_connect("localhost", 11211);
			$cachedObject = $mc->$key;
			logDebug("Valor del objeto: $cachedObject");
			if ($cachedObject)
			{
				
				logDebug("Found a cached response for $mimetype under key $key");
				return true;
			} 
			logDebug("No cached response for $mimetype under key $key");
		}
		logDebug('No suitable cached responses found');
		return false;
	}

	public static function cacheResponse(LinkedDataApiRequest $request, LinkedDataApiResponse $response)
	{
		$cacheableResponse = new LinkedDataApiCachedResponse();
		$cacheableResponse->eTag = $response->eTag;
		$cacheableResponse->generatedTime = $response->generatedTime;
		$cacheableResponse->lastModified = $response->lastModified;
		$cacheableResponse->mimetype = $response->mimetype;
		$cacheableResponse->body = $response->body;

		$key = LinkedDataApiCache::cacheKey($request->uri, $cacheableResponse->mimetype);
		logDebug('Cacheing Response as '.$key.' with mimetype '.$cacheableResponse->mimetype);
		//todo make memcache host and port configurable
		$mc = memcache_connect("localhost", 11211);
		$mc->add($key, $cacheableResponse, false, PUELIA_CACHE_AGE);
	}

	private static function cacheKey($requestUri, $mimetype)
	{
		$key  = $requestUri;
		$key .= trim($mimetype);
		return md5($key);
	}
}
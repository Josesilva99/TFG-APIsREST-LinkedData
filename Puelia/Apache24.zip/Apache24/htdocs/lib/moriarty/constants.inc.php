<?php
// this file is deprecated in favour of moriarty.inc.php
require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'moriarty.inc.php');
?>
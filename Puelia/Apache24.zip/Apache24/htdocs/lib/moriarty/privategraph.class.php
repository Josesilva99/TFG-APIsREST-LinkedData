<?php
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'moriarty.inc.php';
require_once MORIARTY_DIR. 'graph.class.php';

/**
 * Represents a private graph in a store.
 */
class PrivateGraph extends Graph {


}
?>
<?php
require_once 'lda.inc.php';
require 'setup.php';
require_once 'lda-cache.class.php';
require_once 'lda-request.class.php';
require_once 'lda-response.class.php';
require_once 'graphs/configgraph.class.php';
require_once 'responses/Response304.class.php';

Logger::configure("puelia.logging.properties");

$Request = new LinkedDataApiRequest();

$cachedResponse = LinkedDataApiCache::hasCachedResponse($Request);

if ($cachedResponse != false AND PUELIA_SERVE_FROM_CACHE AND !$Request->hasNoCacheHeader())
{
	logDebug("Found cached response");
	if (isset($Request->ifNoneMatch) && $cachedResponse->eTag == $Request->ifNoneMatch)
	{
		logDebug("ETag matched, returning 304");
		$Response = new Response304($cachedResponse);
	}
	else if (isset($Request->ifModifiedSince) && $cachedResponse->generatedTime <= $Request->ifModifiedSince)
	{
		logDebug("Last modified date matched, returning 304");
		$Response = new Response304($cachedResponse);
	}
	else
	{
		logDebug("Re-Serving cached response");
		$Response = $cachedResponse;
	}
}
else
{
	logDebug("Generating fresh response");
	define("CONFIG_URL", $Request->getBaseAndSubDir().'/api-config');
	$ConfigGraph = new ConfigGraph(null, $Request);
	$files = glob('api-config-files/*.ttl');
	foreach($files as $file){
		$ConfigGraph->add_rdf(file_get_contents($file));
	}

	if(rtrim($Request->getPath(), '/')==$Request->getInstallSubDir() OR $ConfigGraph->has_triples_about($Request->getUri()) ){
		header("Location: ".CONFIG_URL, true, 303);
		exit;
	} else if($Request->getBase().$Request->getPathWithoutExtension()==CONFIG_URL){
		require 'config.php';
		exit;
	}

	$ConfigGraph->init();
	$Response =  new LinkedDataApiResponse($Request, $ConfigGraph);
	$Response->process();
}

$Response->serve();
if ($Response->cacheable)
{
	LinkedDataApiCache::cacheResponse($Request, $Response);
}

?>
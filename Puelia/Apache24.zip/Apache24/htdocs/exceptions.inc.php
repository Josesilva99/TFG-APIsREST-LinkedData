<?php
class ConfigGraphException extends Exception {}
class UnknownPropertyException extends Exception {}
?>
<?php

$appRoot = dirname(__FILE__);
set_include_path(get_include_path() . PATH_SEPARATOR . $appRoot);
define('PUELIA_SERVE_FROM_CACHE', true);
define('MORIARTY_HTTP_CACHE_USE_STALE_ON_FAILURE', true);
define('MORIARTY_ALWAYS_CACHE_EVERYTHING', true);
define('MORIARTY_ARC_DIR', 'lib/arc/');
define('MORIARTY_HTTP_CACHE_DIR', dirname(__FILE__). '/cache/');
require 'lib/moriarty/simplegraph.class.php';
define('API', 'http://purl.org/linked-data/api/vocab#');
define('RDFS', 'http://www.w3.org/2000/01/rdf-schema#');
define("XSD", "http://www.w3.org/2001/XMLSchema#");
define("FOAF", 'http://xmlns.com/foaf/0.1/');
define("FOAF_KNOWS", 'http://xmlns.com/foaf/0.1/knows');
define("FOAF_HOMEPAGE", 'http://xmlns.com/foaf/0.1/homepage');
define("REL", 'http://vocab.org/relationship/');
define("RDF", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
define("XHV", "http://www.w3.org/1999/xhtml/vocab#");
define("DCT", "http://purl.org/dc/terms/");
define("OPENSEARCH", "http://a9.com/-/spec/opensearch/1.1/");
define("LOG_SELECT_QUERIES", 1);
define('PUELIA_CACHE_AGE', 1);
//define('PUELIA_CACHE_AGE', (60*60*24*1));
define('PUELIA_LOG_DIR', dirname(__FILE__).'/logs/');
require_once('lib/log4php/src/main/php/Logger.php');

function  getApiConfigAsTurtle(){
    $files = glob('api-config-files/*.ttl');
    $graph = new SimpleGraph();
    foreach($files as $file){
        $graph->add_rdf(file_get_contents($file));
    }
    return $graph->to_turtle();
}

function queryStringToParams($query){
    $query = ltrim($query, '?');
    $pairs = explode('&', $query);
    $params = array();
    foreach($pairs as $pair){
        if($tuple = explode('=', $pair) AND isset($tuple[1])){
            $params[urldecode($tuple[0])]=urldecode($tuple[1]);
        }
    }
    return $params;
}


function logError($message){
    $logger = Logger::getLogger('Puelia');
    $logger->error($message);
}

function logSelectQuery($request, $query){
    $uri = $request->getUri();
    $message = "{$uri}\t<<<{$query}>>>";
    $logger = Logger::getLogger('Puelia');
    $logger->info($message);
    
}
function logViewQuery($request, $query){
    $uri = $request->getUri();
    $message = "{$uri}\t<<<{$query}>>>";
    $logger = Logger::getLogger('Puelia');
    $logger->info($message);
}

function logDebug($message){
    $logger = Logger::getLogger('Puelia');
    $logger->debug($message);
}


?>
<?php
require_once 'lda.inc.php';
//header("Content-type: text/turtle");
$responseTypes = array(
    'text/turtle' => 'turtle',
    'text/plain' => 'turtle',
    'application/rdf+xml' => 'rdf',
    'text/html' => 'html',
    );
if($Request->getFormatExtension()=='ttl'){
    header("Content-type: text/turtle");
    echo $ConfigGraph->to_turtle();
    exit;
}
$acceptTypes = $Request->getAcceptTypes();
foreach($acceptTypes as $mime){
    if(isset($responseTypes[$mime])){
        header("Content-type: {$mime}");
        switch($responseTypes[$mime]){
            case "turtle":
                echo $ConfigGraph->to_turtle();
                break 2;
            case "rdf":
                echo $ConfigGraph->to_rdfxml();
                break 2;
            case "html":
                $DataGraph = $ConfigGraph;
                require 'views/config.html.php';
                break 2;
            
        }
    }
}
?>
<?php
require_once 'graphs/vocabularygraph.class.php';
class SparqlWriter {
    
    private $_config;
    private $_request;
    
    var $_unknownPropertiesFromRequestParameter = array();
    var $_unknownPropertiesFromConfig = array();
    
    function __construct($config, $request){
        $this->_config = $config;
        $this->_request = $request;
    }
    
    
    function getPrefixes(){
        $prefixes = $this->getConfigGraph()->getPrefixesFromLoadedTurtle();
        $sparql = '';
        foreach($prefixes as $p => $ns){
            $sparql.= "PREFIX {$p}: <{$ns}>\n";
        }
        
        return $sparql;
    }
    
    function getLimit(){
        $maxPageSize = $this->getConfigGraph()->getMaxPageSize();
        $requestedPageSize = $this->_request->getParam('_pageSize');
        $endpointDefaultPageSize = $this->getConfigGraph()->getEndpointDefaultPageSize();
        $apiDefaultPageSize = $this->getConfigGraph()->getApiDefaultPageSize();
        if($requestedPageSize > $maxPageSize) return $apiDefaultPageSize;
        else if($requestedPageSize) return $requestedPageSize;
        else if($endpointDefaultPageSize) return $endpointDefaultPageSize;
        else if($apiDefaultPageSize) return $apiDefaultPageSize;
        else return 10;
    }
    
    function getSelectTemplate(){
        if($select = $this->_request->getParam('_select')){
            return $select;
        } else {
            return $this->getConfigGraph()->getSelectQuery();
        }
    }
    
    function getExplicitSelectQuery(){
        if($template = $this->getSelectTemplate()){
            $bindings = $this->getConfigGraph()->getAllProcessedVariableBindings();
            return $this->fillQueryTemplate($template, $bindings);            
        } else {
            return false;
        }
        
    }



    function variableBindingToSparqlTerm($props, $propertyUri=false){
        if(isset($props['type']) AND $props['type']!= RDFS_LITERAL){
            $sparqlVal = "<{$props['value']}>";
        } else {
            $sparqlVal = '"""'.$props['value'].'"""';
            if(isset($props['lang'])){
                $sparqlVal.='@'.$props['lang'];
            } else if(isset($props['datatype'])){
                $sparqlVal.='^^<'.$props['datatype'].'>';
            } else {
               $sparqlVal = $this->addDatatypeToLiteral($sparqlVal, $propertyUri); 
            }
            
        }
        return $sparqlVal;
    }
    
    
    function filterValueToSparqlTerm($val, $propertyUri){
        $varNames = $this->getConfigGraph()->variableNamesInValue($val);
        $bindings = $this->getConfigGraph()->getAllProcessedVariableBindings();
        if($varNames){
            foreach($varNames as $varName){
                if(isset($bindings[$varName])){
                    $binding = $bindings[$varName];
                    return $this->variableBindingToSparqlTerm($binding, $propertyUri);
                } else {
                    throw new ConfigGraphException("The variable {$varName} has no binding");
                }
            }
        } else if($uri = $this->getConfigGraph()->getUriForVocabPropertyLabel($val)){
            return '<'.$uri.'>';
        }
        else {
            
            $literal =  '"""'.$val.'"""';
            return $this->addDatatypeToLiteral($literal, $propertyUri);
        }
    }
    
    function addDatatypeToLiteral($literal, $propertyUri=false){
        if($propertyUri){
            if($propertyRange = $this->getConfigGraph()->getVocabPropertyRange($propertyUri) AND $propertyRange!=RDFS_LITERAL){
                $literal .= '^^<'.$propertyRange.'>';
            }
        }
        return $literal;
    }
    
    function fillQueryTemplate($template, $bindings){
        foreach($bindings as $name => $props){
            $sparqlVal = $this->variableBindingToSparqlTerm($props);
            $sparqlVar = '?'.$name;
            logDebug("SPARQL Variable binding: {$sparqlVal} = {$sparqlVar}");
            //replace all variables with values 
            //(but not variables that simply start with this variable name)
            $template = str_replace($sparqlVar.'.', $sparqlVal, $template);
            $template = str_replace($sparqlVar.',', $sparqlVal, $template);
            $template = str_replace($sparqlVar.';', $sparqlVal, $template);
            $template = str_replace($sparqlVar.' ', $sparqlVal, $template);
        }
        return $template;
    }
    
    function getGroupGraphPattern(){
        $whereRequestParam              =  $this->_request->getParam('_where');
        $selectorConfigWhereProperty    = $this->getConfigGraph()->getSelectWhere();    
        $bindings = $this->getConfigGraph()->getAllProcessedVariableBindings();
        $selectorConfigWhereProperty = $this->fillQueryTemplate($selectorConfigWhereProperty, $bindings);
        
        $GGP = "{$whereRequestParam} \n {$selectorConfigWhereProperty} \n ";
        $filter = implode( '&', $this->getConfigGraph()->getAllFilters());
        foreach($this->_request->getUnreservedParams() as $k => $v){
            $filter.="&{$k}={$v}";
        }
        logDebug("Filter is: {$filter}");
        $GGP .= $this->paramsToSparql(queryStringToParams($filter));
        
        $GGP = trim($GGP);
        if(empty($GGP)){
            $GGP = " { ?item ?property ?value } ";
        }

        return $GGP;
    }
    
    function getGeneratedSelectQuery(){
        $prefixes = $this->getPrefixes();
        $GroupGraphPattern = $this->getGroupGraphPattern();
        $order = $this->getOrderBy();
        $limit = $this->getLimit();
        $offset = $this->getOffset();
        $query = <<<_SPARQL_
{$prefixes}        
SELECT DISTINCT ?item
WHERE 
{
    {$GroupGraphPattern}
    {$order['graphConditions']}
} 
{$order['orderBy']} 
LIMIT {$limit} 
OFFSET {$offset}        
_SPARQL_;
        return $query;
    }
    
    function paramsToSparql($paramsArray){
        $sparql = '';
        $filters = '';
        foreach($paramsArray as $k => $v){
            
            $prefix = $this->prefixFromParamName($k);
            $propertiesList = $this->mapParamNameToProperties($k);
            $propertyNames = array_keys($propertiesList);
            $counter=0;
            $name = $propertyNames[0];
            $varName = $name;
            $nextVarName = '';
            $propUri = $propertiesList[$name];
            $lastPropUri = array_pop(array_values($propertiesList));
            $processedFilterValue = $this->filterValueToSparqlTerm($v, $lastPropUri);
            
            if(count($propertyNames) > 1){
                 $sparql.= "?item <{$propUri}> ?{$name} . ";
            }

            foreach($propertiesList as $name => $propUri){
                if(isset($propertyNames[$counter+1]) OR count($propertyNames)==1){ //if this ISN'T the last property or is the only property
                    if(count($propertyNames)==1){
                        $varName = 'item';
                        $nextName = $propertyNames[0];
                        $nextVarName = $nextName;
                    } else {
                        $nextName = $propertyNames[$counter+1];
                        $nextVarName = $varName.'_'.$nextName;
                        
                    } 
                    
                    $nextProp = $propertiesList[$nextName];
                      
                     //need to cast $nextVarName to compare it with $processedFilterValue
                     $castNextVarName = $this->castOrderByVariable($nextVarName, $nextProp);                      
                                        
                    if ( (($counter+2) == count($propertyNames) OR count($propertyNames)==1) AND !$prefix ){ //if last item or only item
                        $sparql.="?{$varName} <{$nextProp}> {$processedFilterValue} . ";                                               
                    }                     
                    else if(!$prefix) {
                        
                        $sparql.="?{$varName} <{$nextProp}> ?{$nextVarName} .  ";  
                    } else if($prefix=='min') {
                         $sparql.="?{$varName} <{$nextProp}> ?{$nextVarName} . \n FILTER ({$castNextVarName} >= {$processedFilterValue})"; 
                    } else if($prefix=='max') {
                         $sparql.="?{$varName} <{$nextProp}> ?{$nextVarName} . \n FILTER ({$castNextVarName} <= {$processedFilterValue})";
                    } else if($prefix == 'minEx') {
                         $sparql.="?{$varName} <{$nextProp}> ?{$nextVarName} . \n FILTER ({$castNextVarName} > {$processedFilterValue})";
                    } else if($prefix == 'maxEx') {
                          $sparql.="?{$varName} <{$nextProp}> ?{$nextVarName} . \n FILTER ({$castNextVarName} < {$processedFilterValue})";
                    } else if($prefix == 'name') {
                          $sparql.="?{$varName} <{$nextProp}> ?{$nextVarName} .\n ?{$nextVarName} <".RDFS_LABEL."> {$processedFilterValue} . ";
                    } else if($prefix == 'exists') {
                        
                          if($v=="true"){
                              $sparql.="?{$varName} <{$nextProp}> [] .  ";                                               
                          } else {
                              $sparql.="OPTIONAL{ ?{$varName} <{$nextProp}> ?{$nextVarName} .} FILTER (!bound(?{$nextVarName})) ";                                               
                          }
                    } 
                    $varName = $nextVarName;
                    $sparql .= "\n";
                } 
                $counter++;
            }

        
        }
        return  $sparql;
    }
    
        
    
    
    function paramNameToPropertyNames($name){
        #remove min-/max-
        $nameArray = $this->splitPrefixAndName($name);
        $name = $nameArray['name'];
        #split on dot
        $splitNames = explode('.', $name);
        return $splitNames;
    }
    
    function mapParamNameToProperties($name){
        $splitNames = $this->paramNameToPropertyNames($name);
        $list = array();
        foreach($splitNames as $sn){
            $uri = $this->getConfigGraph()->getUriForVocabPropertyLabel($sn);
            $list[$sn] = $uri;
        }
        return $list;
    }
    
    function splitPrefixAndName($name){
        $prefixes = array('min', 'max', 'minEx', 'maxEx', 'name','exists', 'true', 'false');
        foreach($prefixes as $prefix){
            if(strpos($name, $prefix.'-')===0){
                $name =  substr($name, strlen($prefix.'-'));
                return array(
                    'name' => $name,
                    'prefix' => $prefix,
                    );
            }
        }
        return array('name' => $name, 'prefix' => false);
    }
    
    function prefixFromParamName($name){
        $a = $this->splitPrefixAndName($name);
        return $a['prefix'];
    }
    
    function getOffset(){
        $pageNo = $this->_request->getPage();
        return ($pageNo - 1 ) * $this->getLimit();
    }
    
    function getUnknownPropertiesFromRequest(){
        if($this->hasUnknownPropertiesFromRequest()){
            return $this->_unknownPropertiesFromRequestParameter;
        } else {
            return false;
        }
    }

    function getUnknownPropertiesFromConfig(){
        if($this->hasUnknownPropertiesFromConfig()){
            return $this->_unknownPropertiesFromConfig;
        } else {
            return false;
        }
    }
    
    function hasUnknownPropertiesFromRequest(){
        
        if(!empty($this->_unknownPropertiesFromRequestParameter)){
            return true;
        }
        
        foreach($this->_request->getUnreservedParams() as $k => $v){
            $propertyNames = $this->paramNameToPropertyNames($k);
            $propertyNamesWithUris = $this->mapParamNameToProperties($k);
            foreach($propertyNames as $pn){
                  if(empty($propertyNamesWithUris[$pn])){
                        $this->_unknownPropertiesFromRequestParameter[]=$pn;
                    }
            }
            try{
                $chain = $this->getConfigGraph()->getRequestPropertyChainArray();
            } catch (UnknownPropertyException $e){
                $this->_unknownPropertiesFromRequestParameter[]=$e->getMessage();
            }
            
        }

        if(!empty($this->_unknownPropertiesFromRequestParameter)){
            return true;
        }


        return false;
    }
    
    function hasUnknownPropertiesFromConfig($viewerUri=false){

        if(!empty($this->_unknownPropertiesFromConfig)){
              return true;
        }
        
        $filters = $this->getConfigGraph()->getAllFilters();
        foreach($filters as $filter){
            $paramsArray = queryStringToParams($filter);
            foreach(array_keys($paramsArray) as $paramName){
                $propertyNames = $this->paramNameToPropertyNames($paramName);
                $propertyNamesWithUris = $this->mapParamNameToProperties($paramName);
                foreach($propertyNames as $pn){
                    if(empty($propertyNamesWithUris[$pn])){
                        $this->_unknownPropertiesFromConfig[]=$pn;
                    }
                }
            }
            
        }
        
        if($viewerUri){
        try{
                $chain = $this->getConfigGraph()->getViewerDisplayPropertiesValueAsPropertyChainArray($viewerUri);
            } catch (Exception $e){
                $this->_unknownPropertiesFromConfig[]=$e->getMessage();
            }
        }
        if(!empty($this->_unknownPropertiesFromConfig)){
              return true;
        }
        
        return false;
    }
    
    
    function getOrderBy(){
        $graphConditions = false;
        $orderBy = false;
        if($orderByRequestParam = $this->_request->getParam('_orderBy')){
            $orderBy = 'ORDER BY '.$orderByRequestParam;
        } else if($sort = $this->_request->getParam('_sort')){
            return $this->sortToOrderBy($sort, 'request');
        } else if($orderByConfig = $this->getConfigGraph()->getOrderBy()){
            $orderBy = 'ORDER BY '.$orderByConfig;
        } else if($sort = $this->getConfigGraph()->getSort()){
            return $this->sortToOrderBy($sort, 'config');
        }
        return array(
            'graphConditions' => $graphConditions,
            'orderBy' => $orderBy,
        );
    }
    
    function sortToOrderBy($sort, $source){
        $sortPropNames = explode(',',$sort);
        $propertyLists = array();
        foreach($sortPropNames as $sortName){
            $ascOrDesc = ($sortName[0]=='-')? 'DESC' : 'ASC';
            $sortName = ltrim($sortName, '-');
            $propertyLists[]= array(
                    'sort-order' => $ascOrDesc,
                    'property-list'=> $this->mapParamNameToProperties($sortName),
                );
        }
        
        foreach($propertyLists as $propertyList){
            $properties = $propertyList['property-list'];
            foreach($properties as $name => $uri){
                if(empty($uri)){
                    if($source == 'request') $this->_unknownPropertiesFromRequestParameter[]=$name;
                    else if($source == 'config') $this->_unknownPropertiesFromConfig[]=$name;
                    else throw new Exception("source parameter for sortToOrderBy must be 'request' or 'config'");
                }    
            }           
        } 
        return $this->propertyNameListToOrderBySparql($propertyLists);
    }
    
    
    function propertyNameListToOrderBySparql($propertyLists){
        $sparql = '';
        $orderBy = "ORDER BY ";
        $variableNames = array();
        foreach($propertyLists as $propertiesListHash){
            $propertiesList = $propertiesListHash['property-list'];
            $sortOrder = $propertiesListHash['sort-order'];
            $propertyNames = array_keys($propertiesList);
            $counter=0;
            $name = $propertyNames[0];
            $varName = $name;
            $propUri = $propertiesList[$name];
            $sparql.= "?item <{$propUri}> ?{$name} .\n";
            $variableNames[$name] = $propUri;
            foreach($propertiesList as $name => $propUri){
                 if(isset($propertyNames[$counter+1])){ //if this ISN'T the last property
                     $nextName = $propertyNames[$counter+1];
                 } else if (count($propertyNames) ==1){
                     $orderBy.= $sortOrder.'(?'.$name.') ';
                     $varName = 'item';
                     $nextName = $propertyNames[0];
                 }
                 
                 $nextProp = $propertiesList[$nextName];
                 $nextVarName = $varName.'_'.$nextName;

                 if ( ($counter+1) < count($propertyNames)  ){ //if not last item
                     $sparql.="?{$varName} <{$nextProp}> ?{$nextVarName} .";  
                     $variableNames[$nextVarName] = $nextProp; 
                 }
                 
                 if ( ($counter+2) == count($propertyNames) ){
                     //if this is the last property in the chain, add to the order by
                     $orderBy.= $sortOrder.'(?'.$nextVarName.') ';
                 }
                 
                 $varName = $nextVarName;
                 $sparql .= "\n";
                 $counter++;
             }
            
        }
        return array('graphConditions' => $sparql, 'orderBy' => $orderBy); 
    }
    
    
    function getSelectQueryForUriList(){
        if($query = $this->getExplicitSelectQuery()){
            return $this->getPrefixes().$query;
        } else {
            return $this->getGeneratedSelectQuery();
        }
    }    
    
    function castOrderByVariable($varName, $propertyUri){
        $xsdDatatypes = array(
            XSD."integer"  ,
            XSD."int"  ,
            XSD."decimal"  ,
            XSD."float"    ,
            XSD."double"   ,
            XSD."string"   ,
            XSD."boolean"  ,
            XSD."dateTime" ,
            );
        if($propertyRange = $this->getConfigGraph()->getVocabPropertyRange($propertyUri) AND in_array($propertyRange, $xsdDatatypes)){
            return "<{$propertyRange}>(?{$varName})";
        } else {
            return "?{$varName}";
        }
    }    
            
    function getViewQueryForUri($uri, $viewerUri){
        return $this->getViewQueryForUriList(array($uri), $viewerUri);
    }
    
    function getViewQueryForUriList($uriList, $viewerUri){
        
        if(($template = $this->_request->getParam('_template') OR $template = $this->_config->getViewerTemplate($viewerUri)) AND !empty($template)){
          $uriSetFilter = "FILTER( ?item = <http://puelia.example.org/fake-uri/x> ";
          foreach($uriList as $describeUri){
              $uriSetFilter.= "|| ?item = <{$describeUri}> \n";
          }
          $uriSetFilter.= ")\n";
          $prefixes = $this->getPrefixes();
          return "{$prefixes} \n CONSTRUCT { {$template}  } WHERE { {$template} {$uriSetFilter} }";
        } else {
            $conditionsGraph = '';
            $whereGraph = '';
            $variableNameCounter = 1;
            $whereGraph .="\n".' ?s ?p ?o . ';
            if($viewerUri == API.'describeViewer'){
                $requestPropertChains = $this->getConfigGraph()->getRequestPropertyChainArray();
                if(empty($requestPropertChains)){
                    $sparql =  'DESCRIBE <'.implode("> <",$uriList).'>';
                    return $sparql;
                } else {
                    $conditionsGraph .='?s ?p ?o .';
                }
             } else if($viewerUri == API.'labelledDescribeViewer'){
                 $conditionsGraph .= "?s ?p ?o . \n ?o rdfs:label ?label . \n";
                 $whereGraph .= "\n OPTIONAL{ ?o rdfs:label ?label }  \n";
             }
            $chains = $this->getViewerPropertyChains($viewerUri);            
            foreach($chains as $chain){
                  $currentSubject = '?s';
                  $whereGraph .= "\n\t OPTIONAL{\n";
                  foreach($chain as $no => $propertyUri){
                      $variableName = '?v_'.$variableNameCounter++;  
                      $conditionsGraph .= "\n\t {$currentSubject} <{$propertyUri}> {$variableName} . \n";
                      if($currentSubject!='?s') $whereGraph .="\n\t OPTIONAL";
                      $whereGraph .= "{ {$currentSubject} <{$propertyUri}> {$variableName} . } \n";
                      $currentSubject = $variableName;
                  }
                  $whereGraph.="} \n";
              }
              $uriSetFilter = "FILTER( ?s = <http://puelia.example.org/fake-uri/x> || ?s = <http://puelia.example.org/fake-uri/y> ";
              foreach($uriList as $describeUri){
                  $uriSetFilter.= "|| ?s = <{$describeUri}> \n";
              }
              $uriSetFilter.= ")\n";
            return "PREFIX rdfs: <".RDFS."> \n CONSTRUCT \n {  {$conditionsGraph} } \n WHERE \n { \n {$whereGraph} \n  {$uriSetFilter} }";
            
        }
        
    }
    
    function getViewerPropertyChains($viewerUri){
        return array_merge($this->getConfigGraph()->getRequestPropertyChainArray(), $this->getConfigGraph()->getViewerDisplayPropertiesValueAsPropertyChainArray($viewerUri), $this->getConfigGraph()->getAllViewerPropertyChains($viewerUri));
    }
    
    function getConfigGraph(){
        return $this->_config;
    }
    
}
?>
<?php
class LinkedDataApiRequest {
    
    var $formatExtension = null;        
    var $pathWithoutExtension = null;
    var $reservedParams = array(
        '_view',
        '_properties',
        '_template',
        '_format',
        '_page', # is a number; the page that should be viewed
        '_pageSize', # is a number; the number of items per page
        '_sort', # is a comma-separated list of property paths to values that should be sorted on. A - prefix on a property path indicates a descending search
        '_where',# is a "GroupGraphPattern?":http://www.w3.org/TR/rdf-sparql-query/#GroupPatterns (without the wrapping {}s)
        '_orderBy',# is a space-separated list of OrderConditions
        '_select',#
        'callback', # for JSONP
        
        );
    
    function __construct(){
        if (isset($_SERVER['HTTP_IF_NONE_MATCH']))
        {
        	$this->ifNoneMatch = $_SERVER['HTTP_IF_NONE_MATCH'];
        }
        if (isset($_SERVER['HTTP_IF_MODIFIED_SINCE']))
        {
        	$this->ifModifiedSince = strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE']);
        }
        $this->uri = $this->getUri();
    }
    
    function getParams(){
        if(!empty($_SERVER['QUERY_STRING'])){
            return queryStringToParams($_SERVER['QUERY_STRING']);            
        } else {
            return array();
        }

    }
    
    function hasNoCacheHeader(){
        if(
            (isset($_SERVER['HTTP_CACHE_CONTROL']) AND $_SERVER['HTTP_CACHE_CONTROL']=='no-cache')
            OR
            (isset($_SERVER['HTTP_PRAGMA']) AND $_SERVER['HTTP_PRAGMA']=='no-cache')
        ){
            return true;
        } else {
            return false;
        }
    }
    
    function hasUnrecognisedReservedParams(){
        $params = $this->getParams();
        foreach($params as $k => $v){
            if($k[0]=='_' AND !in_array($k, $this->reservedParams)){
                return $k;
            }
        }
        return false;
    }
    function getUnreservedParams(){
        $params = $this->getParams();
        $unreservedParams = array();
        foreach($params as $k => $v){
            if($k[0]!=='_' AND $k!=='callback'){
                $unreservedParams[$k] = $v;
            }
        }
        return $unreservedParams;
    }
    
    function getParam($k){
        $params = $this->getParams();
        if(isset($params[$k])) return $params[$k];
        else return null;
    }
    
    function getInstallSubDir(){
        return $this->_pathIntersect(dirname(__FILE__), $_SERVER['REQUEST_URI']);
    }
    
    function getBase(){
        return 'http://'.$_SERVER['SERVER_NAME'];
    }
    
    function getBaseAndSubDir(){
        return $this->getBase().$this->getInstallSubDir();
    }
            
    function getUri(){
        return $this->getBase().$_SERVER['REQUEST_URI'];
    }
    
    function getPath(){
        return str_replace( '?'.$_SERVER['QUERY_STRING'], '', $_SERVER['REQUEST_URI']);
    }
    
    function getPage(){
        if($page = $this->getParam('_page')){
            return $page;
        } else {
            return 1;
        }
    }
    
    function getView(){
        return $this->getParam('_view');
    }
    
    function getPathWithoutExtension(){
        if(!$this->pathWithoutExtension){
            if($this->hasFormatExtension()){
                $this->pathWithoutExtension = str_replace('.'.$this->getFormatExtension(), '', $this->getPath());                
            } else {
                $this->pathWithoutExtension = $this->getPath();
            }

        }
        return $this->pathWithoutExtension;
    }
    
    function hasFormatExtension(){
        $path = $this->getPath();
        $hasExtension =  preg_match('@^(.+?)\.([a-z]+)$@', $path, $m);
        if($hasExtension){
            $this->pathWithoutExtension = $m[1];
             $this->formatExtension = $m[2];
        }
        return $hasExtension==true;
    }
    
    function getFormatExtension(){
        if($this->hasFormatExtension()){
            return $this->formatExtension;
        } else {
            return false;
        }
    }
    
    function getAcceptHeader(){
        return trim($_SERVER['HTTP_ACCEPT']);
    }
    
    function getAcceptTypes(){
        $header = $this->getAcceptHeader();
        $mimes = explode(',',$header);
    	$accept_mimetypes = array();
    	foreach($mimes as $mime){
    		$parts = explode(';q=', $mime);
    		if(count($parts)>1){
    			$accept_mimetypes[$parts[0]]=$parts[1];
    		}
    		else{
    			$accept_mimetypes[$mime]=1;
    		}
    	}
    	arsort($accept_mimetypes);
    	return array_keys($accept_mimetypes);
    }
    
    function hasAcceptTypes(){
        $acceptHeader = $this->getAcceptHeader();
        if(empty($acceptHeader)){
           return false; 
        } else {
            return true;
        }
    }
    
    function getUriWithoutPageParam(){
        return $this->getUriWithoutParam('_page');
    }
    
    function getUriWithoutViewParam(){
        return $this->getUriWithoutParam('_view');
    }
    
    
    function getUriWithoutParam($params, $stripExtension=false){
        if(is_string($params)){
            $params = array($params);
        }
        if($stripExtension){
            $uri = $this->getBase().$this->getPathWithoutExtension();
        } else {
            $uri = $this->getUri();
        }

        foreach($params as $param){
            $regex= '/'.$param.'=[^&]+/';
            $uri = rtrim(str_replace('?&','?',preg_replace($regex, '', $uri)), '?&');
        }
        return $uri;
    }
   
    function getUriWithParam($paramName, $paramValue=false, $defaultParamValue=false){
           if(!$paramValue) $paramValue = $this->getParam($paramName);
           if(!$paramValue) $paramValue = $defaultParamValue;
           $uri = $this->getUriWithoutParam($paramName);
           if(!strpos($uri, '?')){
                   $uri.='?';
           } else {
               $uri.='&';
           }
           $uri.=$paramName.'='.urlencode($paramValue);
           return $uri;
       }
   
    
    function getUriWithViewParam($viewerName=false){
        return $this->getUriWithParam('_view', $viewerName);
    }
    
    function getUriWithPageParam($pageNo=false, $defaultParamValue=1){
        return $this->getUriWithParam('_page', $pageNo, $defaultParamValue);
    }
    
    function getPageUriWithFormatExtension($extension){
        $uri = $this->getUriWithPageParam();
        if($this->hasFormatExtension()){
            $oldExtension = $this->getFormatExtension();
            if(strpos($uri, '?')){
                return str_replace($oldExtension.'?', $extension.'?', $uri);
             } else {
                return preg_replace('@'.$oldExtension.'$@', $extension, $uri);
             }
        } else {
            if(strpos($uri, '?')){
                return str_replace('?', '.'.$extension.'?', $uri);
             } else {
                return $uri.'.'.$extension;
             }            
        }
    }
    
    function _pathIntersect($a, $b){
        if (strlen($a)<strlen($b)) list($b,$a) = array($a, $b);
    	$pathA = explode('/', $a);
    	$pathB = explode('/', $b);
    	$intersect =  implode('/', array_intersect($pathA, $pathB));
    	if(!empty($intersect)) while(strpos($b, $intersect)===false) $intersect = substr($intersect, 1);
    	return $intersect;
    }
    
}

?>
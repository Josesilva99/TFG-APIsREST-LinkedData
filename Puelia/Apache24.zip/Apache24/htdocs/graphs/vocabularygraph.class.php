<?php
require_once 'lda.inc.php';
require_once 'lib/moriarty/simplegraph.class.php';
require_once 'lib/moriarty/moriarty.inc.php';


class VocabularyGraph extends PueliaGraph {

}


?>
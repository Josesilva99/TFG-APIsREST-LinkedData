<?php

define('HTTP_Unsupported_Media_Type', 'HTTP/1.1 415 Unsupported Media Type');
define('HTTP_OK', 'HTTP/1.1 200 OK');
define('HTTP_Not_Found', 'HTTP/1.1 404 Not Found');
define('HTTP_Internal_Server_Error', 'HTTP/1.1 500 Internal Server Error');
define('HTTP_Bad_Request', 'HTTP/1.1 400 Bad Request');

require_once 'lib/moriarty/moriarty.inc.php';
require_once 'lib/moriarty/sparqlservice.class.php';
require_once 'graphs/linkeddataapigraph.class.php';
require_once 'sparqlwriter.class.php';

class LinkedDataApiResponse {
    
    var $statusCode = HTTP_OK;
    var $Request = false;
    var $ConfigGraph = false;
    var $SparqlWriter = false;
    var $DataGraph = false;
    var $SparqlEndpoint = false;
    var $outputFormats = array(
        'json' => array(
                'ext' => 'json',
                'view' => 'views/simple_json.php',
                'mimetypes' => array(
                        'application/json',
                    ),
            ),
        'ttl' => array(
                'ext' => 'ttl',
                'view' => 'views/turtle.php',
                'mimetypes' => array(
                        'text/plain',
                    ),
            ),
        
        'rdf' => array(
                'ext' => 'rdf',
                'view' => 'views/rdf_xml.php',
                'mimetypes' => array(
                        'application/rdf+xml',
                    ),
            ),
        'xml' => array(
                'ext' => 'xml',
                'view' => 'views/simple_xml.php',
                'mimetypes' => array(
                        'application/xml',
                    ),
            ),
        'html' => array(
                'ext' => 'html',
                'view' => 'views/html.php',
                'mimetypes' => array(
                    'text/html', 'application/xhtml+xml'
                    )
            ),
            
        );
        
    var $pageUri = false;
    var $errorMessages = array();
    
    function __construct($request, $ConfigGraph){

        $this->Request = $request;
        $this->pageUri = $this->Request->getUriWithPageParam();
        $this->ConfigGraph = $ConfigGraph;
        $this->DataGraph = new LinkedDataApiGraph(false, $this->ConfigGraph);
        $this->generatedTime = time();
        $this->lastModified = gmdate("D, d M Y H:i:s") . " GMT";
        $this->cacheable = false;
    }
    
    function process(){

        try{
            if($param = $this->Request->hasUnrecognisedReservedParams()){
                logError("Bad Request: Unrecognised Unreserved Param: {$param}");
                $this->setStatusCode(HTTP_Bad_Request);
                $this->serve();
            }
            $api = $this->ConfigGraph->getApiUri();
            logDebug("API selected: {$api}");
            $endpointUri = $this->ConfigGraph->getEndpointUri();
            logDebug("Endpoint selected: {$endpointUri}");
            $apiUri = $this->ConfigGraph->getApiUri();
            if(empty($endpointUri) OR empty($apiUri)){
                $this->setStatusCode(HTTP_Not_Found);
                $this->serve();
            }
            
            $this->SparqlWriter = new SparqlWriter($this->ConfigGraph, $this->Request);            
            $viewerUri = $this->getViewer();
            if($this->SparqlWriter->hasUnknownPropertiesFromRequest()){
                $this->setStatusCode(HTTP_Bad_Request);
                $this->serve();
            } else if($this->SparqlWriter->hasUnknownPropertiesFromConfig($viewerUri)){
                $this->setStatusCode(HTTP_Internal_Server_Error);
                $unknownProps = implode(', ', $this->SparqlWriter->getUnknownPropertiesFromConfig());
                $msg = "One or more properties named in filters for API {$apiUri} are not in a vocabulary linked to from the API: {$unknownProps}";
                logError($msg);
                $this->errorMessages[]=$msg;
                $this->serve();
            }
        } catch (Exception $e) {
            $this->setStatusCode(HTTP_Internal_Server_Error);
            logError($e->getMessage());
            $this->serve();
        }
        
        
        $requestUri = $this->Request->getUri();

        $endpointUri = $this->ConfigGraph->getEndpointUri();
        try {
            $sparqlEndpointUri = $this->ConfigGraph->getSparqlEndpointUri();
        } catch (Exception $e) {
            $this->setStatusCode(HTTP_Internal_Server_Error);
            logError($e->getMessage());
            $apiUri = $this->ConfigGraph->getApiUri();
            $this->errorMessages[]=" The API is not configured correctly; <{$apiUri}> needs to be given an api:sparqlEndpoint property";
            $this->serve();        
        }
        $this->SparqlEndpoint = new SparqlService($sparqlEndpointUri);

        
        switch($this->ConfigGraph->getEndpointType()){
            case API.'ListEndpoint' : 
                $this->loadDataFromList();    
                break;
            case API.'ItemEndpoint' :
                $this->loadDataFromItem();
                break;
        }
        
        $this->addMetadataToPage();
        
    }
    
    function loadDataFromItem(){
        $uri = $this->ConfigGraph->getCompletedItemTemplate();
        $viewerUri = $this->getViewer();
        $viewQuery  = $this->SparqlWriter->getViewQueryForUri($uri, $viewerUri);
        logViewQuery($this->Request, $viewQuery);
        $response = $this->SparqlEndpoint->graph($viewQuery);
        if($response->is_success()){
            $rdf = $response->body;
            $this->DataGraph->add_rdf($rdf);
            $this->DataGraph->add_resource_triple($this->Request->getUri(), FOAF.'primaryTopic', $uri);
            $this->DataGraph->add_resource_triple($uri , FOAF.'isPrimaryTopicOf',$this->Request->getUri());
        } else {
            logError("Endpoint returned {$response->status_code} {$response->body} View Query <<<{$viewQuery}>>> failed against {$this->SparqlEndpoint->uri}");
            $this->setStatusCode(HTTP_Internal_Server_Error);
            $this->errorMessages[]="The SPARQL endpoint used by this URI configuration did not return a successful response.";
        }
        $this->pageUri = $this->Request->getUri();
    }
    function loadDataFromList(){
        $list = $this->getListOfUris();
        $viewerUri = $this->getViewer();
        logDebug("Viewer URI is $viewerUri");
        $viewQuery  = $this->SparqlWriter->getViewQueryForUriList($list, $viewerUri);
        logViewQuery( $this->Request, $viewQuery);
        $response = $this->SparqlEndpoint->graph($viewQuery);
        if($response->is_success()){
            $rdf = $response->body;
            $this->DataGraph->add_rdf($rdf);
            $listUri = $this->Request->getUriWithoutParam(array('_view', '_page'), 'strip extension');
            // $listUri = $this->Request->getUriWithoutParam(array('_view','_page'));
            $pageUri = $this->Request->getUriWithPageParam();
            $currentPage = $this->Request->getPage();
            $this->DataGraph->add_resource_triple($listUri, RDF_TYPE, API.'List');
            $this->DataGraph->add_resource_triple($pageUri, RDF_TYPE, API.'Page');
            $this->DataGraph->add_resource_triple($listUri, DCT.'hasPart', $pageUri);
            $this->DataGraph->add_resource_triple($pageUri, DCT.'isPartOf', $listUri);
            $this->DataGraph->add_resource_triple($pageUri, XHV.'first', $this->Request->getUriWithPageParam(1));
            if(count($list) >= $this->SparqlWriter->getLimit()){
                $this->DataGraph->add_resource_triple($pageUri, XHV.'next', $this->Request->getUriWithPageParam($currentPage+1));
            }
            if($currentPage > 1){
                $this->DataGraph->add_resource_triple($pageUri, XHV.'prev', $this->Request->getUriWithPageParam($currentPage-1));
            }
            $this->DataGraph->add_literal_triple($pageUri, OPENSEARCH.'itemsPerPage', $this->SparqlWriter->getLimit(), null, XSD.'integer');
            $this->DataGraph->add_literal_triple($pageUri, OPENSEARCH.'startIndex', $this->SparqlWriter->getOffset(), null, XSD.'integer');
            $this->DataGraph->add_literal_triple($pageUri, DCT.'modified', date("Y-m-d\TH:i:s"), null, XSD.'dateTime' );
            $rdfListUri = '_:itemsList';
            $this->DataGraph->add_resource_triple($pageUri, API.'items', $rdfListUri);
            $this->DataGraph->add_resource_triple($rdfListUri, RDF_TYPE, RDF_LIST);
            foreach($list as $no => $resourceUri){
                $nextNo = ($no+1);
                $nextList = (($no+1) == count($list))? RDF_NIL : '_:itemsList'.$nextNo;
                $this->DataGraph->add_resource_triple($rdfListUri, RDF_FIRST, $resourceUri);
                $this->DataGraph->add_resource_triple($rdfListUri, RDF_REST, $nextList);
                $rdfListUri = $nextList;
            }
            
        } else {
            logError("Endpoint returned {$response->status_code} {$response->body} View Query <<<{$viewQuery}>>> failed against {$this->SparqlEndpoint->uri}");
            $this->setStatusCode(HTTP_Internal_Server_Error);
            $this->errorMessages[]="The SPARQL endpoint used by this URI configuration did not return a successful response.";
            
        }
        
    }
    
    
    function getViewer(){
        if($name = $this->Request->getView()){
            logDebug("Viewer Name from Request is $name");
            if($viewerUri = $this->ConfigGraph->getViewerByName($name)){
                return $viewerUri;
            } else {
                logError("Bad Request when picking viewer for {$name}");
                $this->errorMessages[]="There is no viewer called \"{$name}\" for this endpoint";
                $this->setStatusCode(HTTP_Bad_Request);
            }
        } else {
            if($viewerUri = $this->ConfigGraph->getEndpointDefaultViewer()){
                return $viewerUri;
            } else if($viewerUri = $this->ConfigGraph->getApiDefaultViewer()){
                return $viewerUri;
            } else {
                return  API.'describeViewer';
            }
        }
    }
    
    function getListOfUris(){
        $list = array();
        try {
            $selectQuery = $this->SparqlWriter->getSelectQueryForUriList(); 
        } catch (Exception $e){
            logError($e->getMessage());
            $this->setStatusCode(HTTP_Internal_Server_Error);
            $this->errorMessages[]="There was a problem generating the SPARQL query for this request. There may be a configuration error.";
            $this->serve();
        }
        if(LOG_SELECT_QUERIES){
            logSelectQuery($this->Request, $selectQuery);
        }
        
        $response = $this->SparqlEndpoint->select($selectQuery);
        
        if($response->is_success()){
            $xml = $response->body;
            $results = $this->SparqlEndpoint->parse_select_results($xml);
            
            foreach($results as $row){
                $list[]=$row['item']['value'];
            }
            
        } else {
            logError("Endpoint returned {$response->status_code} {$response->body} Select Query <<<{$selectQuery}>>> failed against {$this->SparqlEndpoint->uri}");
            $this->setStatusCode(HTTP_Internal_Server_Error);
            $this->errorMessages[]="The SPARQL endpoint used by this URI configuration did not return a successful response.";
            
        }
        return $list;
    }
    
    function setStatusCode($code){
        $this->statusCode = $code;
    }
    
    function extensionIsSupported($ext){
        foreach($this->outputFormats as $name => $props){
            if($props['ext'] == $ext){
                return true;
            }
        }
        if($formatUri = $this->ConfigGraph->getFormatterUriByName($ext)) return true;
        return false;        
    }
    
    function getOutputFormat(){
        if($this->Request->hasFormatExtension()){
            $extension = $this->Request->getFormatExtension();
            if($this->extensionIsSupported($extension)){
                foreach($this->outputFormats as $name => $props){
                    if($props['ext'] == $extension){
                        return $name;
                    }
                }
            } else {
                $this->setStatusCode(HTTP_Unsupported_Media_Type);
                return false;
            } 
        } 
        else if($this->Request->hasAcceptTypes()){
            foreach($this->Request->getAcceptTypes() as $acceptType){
                foreach($this->outputFormats as $formatName => $props){
                    if($props['ext'] == $acceptType || $acceptType == '*/*'){
                        return $formatName;
                    }
                }
            }
            return false;
        } else {
            return false;
        }
    }
  

  function addMetadataToPage(){
      $endpointUrl = $this->ConfigGraph->getEndpointUri();
      if(strpos($endpointUrl, '_:')===0) $endpointUrl = CONFIG_URL;
      $this->DataGraph->add_resource_triple($this->pageUri, API.'definition', $endpointUrl);
      $currentFormat = $this->getOutputFormat();
      foreach($this->ConfigGraph->getViewers() as $viewer){
          $viewerName=$this->ConfigGraph->get_first_literal($viewer, API.'name');
          $altViewUri = $this->Request->getUriWithViewParam($viewerName);
          $this->DataGraph->add_resource_triple($this->pageUri, DCT.'hasVersion', $altViewUri);
          $this->DataGraph->add_resource_triple($altViewUri, DCT.'isVersionOf',  $this->pageUri);
          $this->DataGraph->add_literal_triple($altViewUri, RDFS_LABEL,  $viewerName);
      }

      foreach($this->ConfigGraph->getFormatters() as $formatName => $formatUri){
          $altFormatUri = $this->Request->getPageUriWithFormatExtension($formatName);
          if($this->pageUri!==$altFormatUri){
              $this->DataGraph->add_resource_triple($this->pageUri, DCT.'hasFormat', $altFormatUri);
              $this->DataGraph->add_resource_triple($altFormatUri, DCT.'isFormatOf', $this->pageUri);
              $this->DataGraph->add_resource_triple($altFormatUri, DCT.'format', '_:format_'.$formatName);
              $this->DataGraph->add_literal_triple($altFormatUri, RDFS_LABEL, $formatName);
              $mimetype = $this->ConfigGraph->getMimetypeOfFormatterByName($formatName);
              $this->DataGraph->add_literal_triple('_:format_'.$formatName, RDFS_LABEL, $mimetype);
        }
      }
      
  }
  
  
  function getFormatter(){
      if($format = $this->Request->getParam('_format')){
          if($this->ConfigGraph->getApiContentNegotiation()==API.'parameterBased' AND $this->ConfigGraph->apiSupportsFormat($format)){
              return $format;
          } else {
              logError("Bad Request when selecting formatter: {$format}");
              $this->setStatusCode(HTTP_Bad_Request);
              $this->serve();
          }
      } else if($this->Request->hasFormatExtension()) { 
          $extension = $this->Request->getFormatExtension();
          if($this->extensionIsSupported($extension)){
                return $extension;
          } else {
              $this->setStatusCode(HTTP_Unsupported_Media_Type);
              return false;
          } 
          
         }  else if($this->Request->hasAcceptTypes()){
                  foreach($this->Request->getAcceptTypes() as $acceptType){
                      foreach($this->ConfigGraph->getFormatters() as $formatName => $formatterUri){
                          $formatterMimetype = $this->ConfigGraph->getMimetypeOfFormatterByName($formatName);
                          if($formatterMimetype == $acceptType || $acceptType == '*/*'){
                              return $formatName;
                          }

                      }
                  }
        } else if($formatUri = $this->ConfigGraph->getEndpointDefaultFormatter()){ 
            return $this->ConfigGraph->get_first_literal($formatUri, API.'name');
        } else if($formatUri = $this->ConfigGraph->getApiDefaultFormatter()){ 
            return $this->ConfigGraph->get_first_literal($formatUri, API.'name');
        } 
        
        return 'json';
        
  }
  
  
  function serve(){
              $Request = $this->Request;
              header($this->statusCode);

              if($this->statusCode == HTTP_OK){
                  try {

                  $outputFormat = $this->getFormatter();

          
                  if(!$outputFormat){
                      throw new Exception("No output format provided");
                  }
                $mimetype = $this->ConfigGraph->getMimetypeOfFormatterByName($outputFormat);
                $this->mimetype = $mimetype;
                if($this->ConfigGraph->getFormatterTypeByName($outputFormat)== API.'XsltFormatter'){
                    $viewFile = 'views/xslt.php';
                    $styleSheetFile = $this->ConfigGraph->getXsltStylesheetOfFormatterByName($outputFormat);
                    require $viewFile;
                    die;
                } else if(isset($this->outputFormats[$outputFormat])) {
                    $viewFile = $this->outputFormats[$outputFormat]['view'];
                } else {
                  throw new Exception("{$outputFormat} is not an accepted output format");
                }
            } 
        catch(Exception $e){
            logError("Bad Request when serving response: ".$e->getMessage());
            $this->setStatusCode(HTTP_Bad_Request);
            $this->serve();
        }
        header("Content-Type: {$mimetype}");
        header("Last-Modified: {$this->lastModified}");
		header("x-served-from-cache: false");
        $DataGraph = $this->getDataGraph();
        try {
            ob_start();
            require $viewFile;
            $page = ob_get_clean();
            $this->eTag = md5($page);
			header("ETag: {$this->eTag}");
            $this->body = $page;
            echo $page;
            $this->cacheable = true;
        } catch (Exception $e){
            $this->setStatusCode(HTTP_Internal_Server_Error);
            $this->errorMessages[]="Sorry, Puelia experienced an error trying to serve this page.";
            logError('Error from Response:serve() '.$e->getMessage());
            $this->serve();
            exit;
        }
      } else {
          header("Content-type: text/html");
          switch($this->statusCode){
              case HTTP_Unsupported_Media_Type:
              case HTTP_Bad_Request :
                require 'views/errors/400.php';
                break;
              default:
              case HTTP_Internal_Server_Error :
                require 'views/errors/500.php';
                break;
              case HTTP_Not_Found :
                require 'views/errors/404.php';
                break;
              
          }
          exit;
      }
      
  }  
    
    function getDataGraph(){
        return $this->DataGraph;
    }
        
}


?>